# Learn and Earn AI — Prototype 0.2

## Run locally
1. Extract this ZIP.
2. Open `index.html` in a current browser.
3. Edit the example and press **Run**.

## Demo language (very limited)
```text
let name = "friend"
print("Hello, " + name)
let number = 10
print(number + 5)
```
The interpreter does not use JavaScript `eval`. It supports only simple variable assignments, `print(...)`, strings, numbers, and `+`.

## What's improved
- English-first interface and responsive layout.
- Accessible labels, visible keyboard focus, skip link, and live output announcements.
- Clear limitations and privacy notice.
- Basic syntax error messages.
- No account, server, or network transmission in this static demo.

## Not included yet
This is not production-ready and does not include real AI, full Versa language, lexer/parser, loops, conditions, functions, cloud saving, user accounts, Google/Facebook/Instagram authentication, visual blocks, or eye-gaze control. Never claim these features exist until implemented and tested.

## Publish on GitHub Pages
1. Sign in to GitHub and create a public repository such as `learn-and-earn-ai`.
2. Upload `index.html` and `README.md`.
3. Go to **Settings → Pages**.
4. Select **Deploy from a branch**, branch `main`, folder `/(root)`, and save.
5. Wait for the Pages URL to appear.
6. Test the public URL on phone and computer.

## Security note
Do not collect passwords or implement social login by putting secrets in front-end JavaScript. Real authentication requires a trusted provider and a server-side or managed auth flow, careful redirect configuration, HTTPS, privacy disclosures, and security testing. This prototype deliberately has no sign-in.
